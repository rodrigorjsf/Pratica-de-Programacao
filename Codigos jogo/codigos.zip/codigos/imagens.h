/*
 * segunda.h
 *
 *  Created on: 26 de mai de 2017
 *      Author: Rodrigo
 */

#ifndef IMAGENS_H_
#define IMAGENS_H_

#include <allegro.h>

int segunda_tela();


#endif /* IMAGENS_H_ */
