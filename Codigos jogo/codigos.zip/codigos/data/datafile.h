/* Allegro datafile object indexes, produced by grabber v4.2.0, MSVC.s */
/* Datafile: c:\Users\Rodrigo\workspace\RACHA CUCA\Debug\data.dat */
/* Date: Thu Jun 01 02:34:49 2017 */
/* Do not hand edit! */

#define BACKGROUND                       0        /* BMP  */
#define CURSOR                           1        /* BMP  */
#define CURSORATIVO                      2        /* BMP  */
#define DIFICIL                          3        /* BMP  */
#define DIFICILATIVO                     4        /* BMP  */
#define ESCOLHA                          5        /* BMP  */
#define FACIL                            6        /* BMP  */
#define FACILATIVO                       7        /* BMP  */
#define FUNDO                            8        /* BMP  */
#define GAMEFONT                         9        /* FONT */
#define GHOST_FIVE                       10       /* BMP  */
#define GHOST_FOUR                       11       /* BMP  */
#define GHOST_TREE                       12       /* BMP  */
#define JOGAR                            13       /* BMP  */
#define JOGARATIVO                       14       /* BMP  */
#define LOGO                             15       /* BMP  */
#define MEDALHA                          16       /* BMP  */
#define MEDIO                            17       /* BMP  */
#define MEDIOATIVO                       18       /* BMP  */
#define MUTE                             19       /* BMP  */
#define NOVORECORDE                      20       /* BMP  */
#define PLAY                             21       /* BMP  */
#define RECORDEATUAL                     22       /* BMP  */
#define SAIR                             23       /* BMP  */
#define SAIRATIVO                        24       /* BMP  */
#define VOLTAR                           25       /* BMP  */
#define VOLTARATIVO                      26       /* BMP  */

