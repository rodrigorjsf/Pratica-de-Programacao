/* Allegro datafile object indexes, produced by grabber v4.2.0, MSVC.s */
/* Datafile: c:\Users\Rodrigo\workspace\Jogo\Debug\sons.dat */
/* Date: Wed May 31 18:45:11 2017 */
/* Do not hand edit! */

#define CLICK                            0        /* SAMP */
#define MUSICA                           1        /* MIDI */
#define RECORD                           2        /* SAMP */
#define VITORIA                          3        /* SAMP */

