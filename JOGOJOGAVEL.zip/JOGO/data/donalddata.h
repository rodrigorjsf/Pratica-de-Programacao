/* Allegro datafile object indexes, produced by grabber v4.2.0, MSVC.s */
/* Datafile: c:\Users\Rodrigo\workspace\RACHA CUCA\Debug\donald.dat */
/* Date: Thu Jun 01 02:00:15 2017 */
/* Do not hand edit! */

#define D_TRES_CINCO                     0        /* BMP  */
#define D_TRES_DOIS                      1        /* BMP  */
#define D_TRES_OITO                      2        /* BMP  */
#define D_TRES_QUATRO                    3        /* BMP  */
#define D_TRES_SEIS                      4        /* BMP  */
#define D_TRES_SETE                      5        /* BMP  */
#define D_TRES_TRES                      6        /* BMP  */
#define D_TRES_UM                        7        /* BMP  */
#define DONALD                           8        /* BMP  */
#define DONALDMEDIOCINCO                 9        /* BMP  */
#define DONALDMEDIOQUATRO                10       /* BMP  */
#define DONALDMEDIOTRES                  11       /* BMP  */

