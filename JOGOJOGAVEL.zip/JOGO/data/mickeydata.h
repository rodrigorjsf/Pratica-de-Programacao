/* Allegro datafile object indexes, produced by grabber v4.2.0, MSVC.s */
/* Datafile: c:\Users\Rodrigo\workspace\Jogo\Debug\mickey.dat */
/* Date: Wed May 31 18:29:05 2017 */
/* Do not hand edit! */

#define MICKEY                           0        /* BMP  */
#define MICKEYMEDIOTRES                  1        /* BMP  */
#define MICKEYMEDIOQUATRO                2        /* BMP  */
#define MICKEYMEDIOCINCO                 3        /* BMP  */
#define M_TRES_UM                        4        /* BMP  */
#define M_TRES_DOIS                      5        /* BMP  */
#define M_TRES_TRES                      6        /* BMP  */
#define M_TRES_QUATRO                    7        /* BMP  */
#define M_TRES_CINCO                     8        /* BMP  */
#define M_TRES_SEIS                      9        /* BMP  */
#define M_TRES_SETE                      10       /* BMP  */
#define M_TRES_OITO                      11       /* BMP  */

